// app.js
export function initApp() {
    console.log('Travel Planner App Initialized');
  }
  