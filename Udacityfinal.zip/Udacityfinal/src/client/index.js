// index.js
import './styles/main.scss';
import { initApp } from './js/app';

document.addEventListener('DOMContentLoaded', () => {
  initApp();
});
